chk=`whoami`

if [[ $chk == "root" ]]
then
	echo " "
else
	echo "Administrative privilege required, unless the application will not work."
	echo " "
	echo "So Installation of Network Builder v0.1 is not possible, please login with root privilege."
	exit
fi

pth=`pwd`
mkdir /etc/Tools/

ping -c 3 www.google.com
pn=`echo $?`

if [[ $pn -eq 0 ]]
then
	yum install nfs -y
	echo "NFS package is installed."
else
	echo "Please connect to Internet. To install this software you need to connected to internet."
	exit
fi

cp Tools.tar /etc/Tools/
cp ClientNetworkBuilderv0.1.desktop /root/Desktop/

cd /etc/Tools/
tar -xvf /etc/Tools/Tools.tar>/dev/null
rm -f /etc/Tools/Tools.tar

rm -f /bin/netbldctool
touch /bin/netbldctool
echo "cd /etc/Tools">/bin/netbldctool
echo "java tool">>/bin/netbldctool
chmod 777 /bin/netbldctool
