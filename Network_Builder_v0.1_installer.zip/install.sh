chk=`whoami`

if [[ $chk == "root" ]]
then
	echo " "
else
	echo "Administrative privilege required, unless the application will not work."
	echo " "
	echo "So Installation of Network Builder v0.1 is not possible, please login with root privilege."
	exit
fi

pth=`pwd`
mkdir /etc/Network_Builder_V0.1/
mkdir /etc/Network_Builder_V0.1/logs
mkdir /etc/Network_Builder_V0.1/logs/NBV0.1_MANUALS/
mkdir /etc/Network_Builder_V0.1/logs/DHCP
mkdir /etc/Network_Builder_V0.1/logs/DNS
mkdir /etc/Network_Builder_V0.1/logs/HTTP
mkdir /etc/Network_Builder_V0.1/logs/NFS
mkdir /etc/Network_Builder_V0.1/logs/NAT
mkdir /etc/Network_Builder_V0.1/logs/FTP

ping -c 3 www.google.com
pn=`echo $?`

if [[ $pn -eq 0 ]]
then
	yum install dhcp -y
	echo "DHCP package is installed."
	yum install bind -y
	echo "BIND package is installed."
	yum install nfs -y
	echo "NFS package is installed."
	yum install httpd -y
	echo "HTTP package is installed."
	yum install vsftpd -y
	echo "FTP package is installed."
else
	echo "Please connect to Internet. To install this software you need to connected to internet."
	exit
fi



cp NETWORK_BUILDER_V0.1.tar /etc/Network_Builder_V0.1/
cp NetworkBuilderv0.1.desktop /root/Desktop/
cp Manuals.tar /etc/Network_Builder_V0.1/logs/NBV0.1_MANUALS/

cd /etc/Network_Builder_V0.1/
tar -xvf /etc/Network_Builder_V0.1/NETWORK_BUILDER_V0.1.tar>/dev/null
rm -f /etc/Network_Builder_V0.1/NETWORK_BUILDER_V0.1.tar

cd /etc/Network_Builder_V0.1/logs/NBV0.1_MANUALS/
tar -xvf /etc/Network_Builder_V0.1/logs/NBV0.1_MANUALS/Manuals.tar>/dev/null
rm -f /etc/Network_Builder_V0.1/logs/NBV0.1_MANUALS/Manuals.tar

rm -f /bin/netbld
touch /bin/netbld
echo "cd /etc/Network_Builder_V0.1">/bin/netbld
echo "whoami > user.usr">>/bin/netbld
echo "java mainwindow">>/bin/netbld
chmod 777 /bin/netbld
