Network Builder� Version 0.1 20/11/2013


GENERAL USAGE NOTES
--------------------

- NetworkBuilder does not support Windows, Macintosh or Debian Linux distributions so 
  it is recommended to users to use CentOS or RHEL distributions.If you use CentOS then
  it is also recommended to install Desktop packages for best result.

- Be aware that there is essential need of root login and then run the installer
  which will create a short-cut of NetworkBuilder at root's Desktop and moreover to
  work successfully on this tool user should have to remain root because many of tool's
  functions for creating servers, starting/stopping servers and updating servers can 
  only possible at root user privilege.

- Progresses of this software are estimation only and may pause for several minutes,
  even though NetworkBuilder is still working correctly. If you think your computer
  has locked up, please be patient and let NetworkBuilder to finish it's operations.

  As a hint of these kind of situation, we want to let user know that same situation 
  can be arise in case of FTP server set-up so allow software to take it's time and 
  it's highly recommended to wait 25-30 minutes for it's completion.

- Most Importantly this software needed some packages name of which will be provided
  with configuration manuals individually must be installed into system using internet
  as specified to user.
----------------------------------------------------------------------------------------

Installing under CentOS 6
----------------------------
When Installing NetworkBuilder program from CentOS 6.4 or CentOS 6.3, it is
recommended that you install to root user. If you do install to a normal user,
you can't able to get best result of this program and also program get crashed
due to lack of administrative privileges. Use "install" file to install the 
program to your system as follows;

[root@systemX]# bash install.sh

========================================================================================

Network Builder Program can be reached at

Website: http://networkbuilder.tk
E-mail:	networkbuilder@aol.com

Copyright � 2012-2022 A2S2 Corporation. All rights reserved.
NetworkBuilder and its use are subject to a license agreement and are 
also subject to copyright, trademark, patent and/or other laws.
Refer to user guide(manuals) or www.networkbuilder.com/legal for additional
information about NetworkBuilder patents.
